phrase = "Don't panic!"
plist = list(phrase)
print(phrase)
print(plist)
new_phrase = []
new_phrase.append(plist[1])
new_phrase.append(plist[2])
new_phrase.append(plist[5])
new_phrase.append(plist[4])
new_phrase.append(plist[7])
new_phrase.append(plist[6])

print(plist)
print(new_phrase)

for letter in new_phrase:
    print(letter)

np = ''.join(new_phrase)
print(np)
