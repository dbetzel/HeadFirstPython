from datetime import datetime

import random
import time

for i in range(5):
    right_this_minute = datetime.today().minute
    if right_this_minute % 2 == 0:
        print("Not an odd minute.")
    else:
        print("This minute seems a little odd.")
    wait_time = random.randint(1,60)
    time.sleep(wait_time)
